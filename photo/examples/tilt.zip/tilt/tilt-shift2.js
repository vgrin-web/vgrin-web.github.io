
// Javascript copyright Sean T. McHugh
// Cambridge in Colour Photography
// http://www.cambridgeincolour.com

//----------
function tscalc0(tsform0) {
coc = 1*document.tsform0.format.options[document.tsform0.format.selectedIndex].value;
aperture = 1*document.tsform0.aperture.options[document.tsform0.aperture.selectedIndex].value;
focal = tsform0.focal0.value; // in mm
tilt = tsform0.tilt0.value; // in degrees
distance = tsform0.distance.value;
distance_unit = tsform0.distance_unit.value; // dividing by this converts input into meters

if ( isNaN(focal) || focal <= 0 ) {
alert('Please enter a positive numerical value for the focal length in mm.');
document.tsform0.focal0.focus();
document.tsform0.focal0.select();
}
else {
if ( isNaN(tilt) || tilt < 0.5 ) {
alert('Please enter a numerical value of at least 0.5 degrees for the lens tilt.');
document.tsform0.tilt0.focus();
document.tsform0.tilt0.select();
}
else {
if ( isNaN(distance) || distance < 0.3 ) {
alert('Please enter a numerical value of at least 0.3 meters for the focusing distance.');
document.tsform0.distance.focus();
document.tsform0.distance.select();
}
else {

distance_mm = 1000*distance/distance_unit; // converts distance to mm's
tilt = (Math.PI/180) * tilt; // converts tilt from degrees into radians

jval = 0.001 * focal / Math.sin( tilt ); // in meters
A = focal / ( 1-focal/distance_mm ); // this value is very susceptible to errors caused by the thin lens approximation

phi = (180/Math.PI) * Math.atan( Math.sin(tilt) / ( Math.cos(tilt) - focal/A ) ); // angle of focal plane relative to unshifted position, in direction of tilt
if ( phi < 0 ) { phi = 180 + phi; } // if focal plane is rotated past ninety degrees
tsform0.fplanerot0.value = Math.round(10 * phi) / 10 + "\u00B0";
tsform0.jval.value = Math.round(10 * jval) / 10 + " m";

//calculated near and far planes of acceptable sharpness
stemp = focal / ( coc * aperture );
dnear = A / (stemp-1); // near depth of focus
dfar = A / (stemp+1); // far depth of focus

neardofangle = (180/Math.PI) * Math.atan( Math.sin(tilt) / ( Math.cos(tilt) - focal/(A+dnear) ) ); // near depth of field angle in degrees
fardofangle = (180/Math.PI) * Math.atan( Math.sin(tilt) / ( Math.cos(tilt) - focal/(A-dfar) ) ); // far depth of field angle in degrees
if ( fardofangle < 0 ) { fardofangle = 180 + fardofangle; }
if ( neardofangle < 0 ) { neardofangle = 180 + neardofangle; }

tsform0.dnear.value = Math.round(10 * neardofangle) / 10 + "\u00B0";
tsform0.dfar.value = Math.round(10 * fardofangle) / 10 + "\u00B0";
tsform0.dtotaov.value = Math.round(10 * (fardofangle-neardofangle) ) / 10 + "\u00B0";

}
}
}

}

//----------
function tscalc1(tsform1) {

focal = tsform1.focal1.value; // in mm
shiftamount = tsform1.shift1.value; // in mm

if ( isNaN(focal) || focal <= 0 ) {
alert('Please enter a positive numerical value for the focal length.');
document.tsform1.focal1.focus();
document.tsform1.focal1.select();
}
else {
if ( isNaN(shiftamount) || shiftamount <= 0 ) {
alert('Please enter a positive numerical value for the shift amount.');
document.tsform1.shift1.focus();
document.tsform1.shift1.select();
}
else {

angle = (180/Math.PI) * Math.atan( shiftamount / focal ); // long dimension angle of view in degrees
tsform1.fplanerot1.value = Math.round(10 * angle) / 10 + "\u00B0";

}
}

}

(function( $ ) {

// jquery toggle function to reveal advanced options
$(".advanced").click(function () {
	$(".showhide").toggle('slow');
	$("span.show-adv").toggle();
	$("span.hide-adv").toggle();
});

})(jQuery);

//----------
function tscalc0inv(tsform0) {
    coc = 1 * document.tsform0.format.options[document.tsform0.format.selectedIndex].value;
    aperture = 1 * document.tsform0.aperture.options[document.tsform0.aperture.selectedIndex].value;
    focal = tsform0.focal0.value; // in mm
    jval = tsform0.jval.value; // in cm
    distance = tsform0.distance.value;
    distance_unit = tsform0.distance_unit.value; // dividing by this converts input into meters

    if (isNaN(focal) || focal <= 0) {
        alert('Please enter a positive numerical value for the focal length in mm.');
        document.tsform0.focal0.focus();
        document.tsform0.focal0.select();
    }
    else {
        if (isNaN(jval) || jval < 10) {
            alert('Please enter a numerical value of at least 10 cm degrees for the Vertical Distance.');
            document.tsform0.jval.focus();
            document.tsform0.jval.select();
        }
        else {
            if (isNaN(distance) || distance < 0.3) {
                alert('Please enter a numerical value of at least 0.3 meters for the focusing distance.');
                document.tsform0.distance.focus();
                document.tsform0.distance.select();
            }
            else {

                distance_mm = 1000 * distance / distance_unit; // converts distance to mm's

                jval = 0.01 * jval;    // in meters
                tilt = Math.asin(0.001 * focal / jval); // in radians

                tiltd = (180 / Math.PI) * tilt; // converts tilt from radians into degrees

                A = focal / (1 - focal / distance_mm); // this value is very susceptible to errors caused by the thin lens approximation

                phi = (180 / Math.PI) * Math.atan(Math.sin(tilt) / (Math.cos(tilt) - focal / A)); // angle of focal plane relative to unshifted position, in direction of tilt
                if (phi < 0) { phi = 180 + phi; } // if focal plane is rotated past ninety degrees
                tsform0.fplanerot0.value = Math.round(10 * phi) / 10 + "\u00B0";
                tsform0.tilt0.value = Math.round(10 * tiltd) / 10 + "\u00B0";

                //calculated near and far planes of acceptable sharpness
                stemp = focal / (coc * aperture);
                dnear = A / (stemp - 1); // near depth of focus
                dfar = A / (stemp + 1); // far depth of focus

                neardofangle = (180 / Math.PI) * Math.atan(Math.sin(tilt) / (Math.cos(tilt) - focal / (A + dnear))); // near depth of field angle in degrees
                fardofangle = (180 / Math.PI) * Math.atan(Math.sin(tilt) / (Math.cos(tilt) - focal / (A - dfar))); // far depth of field angle in degrees
                if (fardofangle < 0) { fardofangle = 180 + fardofangle; }
                if (neardofangle < 0) { neardofangle = 180 + neardofangle; }

                tsform0.dnear.value = Math.round(10 * neardofangle) / 10 + "\u00B0";
                tsform0.dfar.value = Math.round(10 * fardofangle) / 10 + "\u00B0";
                tsform0.dtotaov.value = Math.round(10 * (fardofangle - neardofangle)) / 10 + "\u00B0";

            }
        }
    }

}
